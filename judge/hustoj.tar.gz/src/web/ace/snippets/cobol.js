ace.define("ace/snippets/cobol",[], function(require, exports, module) {
"use strict";

exports.snippetText = "";
exports.scope = "cobol";

});
                (function() {
                    ace.require(["ace/snippets/cobol"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            